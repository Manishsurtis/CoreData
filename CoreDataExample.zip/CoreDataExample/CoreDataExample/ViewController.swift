//
//  ViewController.swift
//  CoreDataExample
//
//  Created by Manish Surti on 14/06/2017.
//  Copyright © 2017 ASquare.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var fname: UITextField!
    @IBOutlet weak var textdesc: UITextField!
    var studint  = 0
    var stud:[Student] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //studint = 0
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func SaveAction(_ sender: Any) {

        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let student = Student(context: context)
    
        if (UserDefaults.standard.value(forKey: "studid") != nil)
        {
            let ids = UserDefaults.standard.value(forKey: "studid") as! String
            let studid = Int(ids)
            let idint = studid! + 1
            let getid = String(idint)
            student.id = getid
            student.name = fname.text
            student.studescription = textdesc.text
            
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
            UserDefaults.standard.setValue(student.id, forKey: "studid")
        }
        else{
        let idint = studint + 1
            let getid = String(idint)
            student.id = getid
            student.name = fname.text
            student.studescription = textdesc.text
            
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
            //UserDefaults.setValue(student.id, forKey: "studid")
            UserDefaults.standard.setValue(student.id, forKey: "studid")

        }
        
        
    }
    @IBAction func FetchAction(_ sender: Any) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
    
        do{
            stud = try context.fetch(Student.fetchRequest())
            
            for i in stud{
                    print(i.name!)
                    print(i.studescription!)
                print(i.id!)
            }
        }
        catch{
            
        }
    }
    

}

