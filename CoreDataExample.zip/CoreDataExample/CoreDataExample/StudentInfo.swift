//
//  StudentInfo.swift
//  CoreDataExample
//
//  Created by Manish Surti on 14/06/2017.
//  Copyright © 2017 ASquare.com. All rights reserved.
//

import UIKit

class StudentInfo: NSObject {

    var ids = String()
    var name = String()
    var studDesc = String()
}
